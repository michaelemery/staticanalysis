#! /bin/sh -eu

ocamlbuild p1.cma p1.cmxa
