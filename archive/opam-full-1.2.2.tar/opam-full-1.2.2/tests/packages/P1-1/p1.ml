let x () =
  try Random.int 10
  with _ -> 0
