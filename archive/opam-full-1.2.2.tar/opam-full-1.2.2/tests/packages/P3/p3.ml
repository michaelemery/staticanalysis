let z () =
  try P1.x ()
  with _ -> 0
